# trustbom

The `trustbom` CLI (alias `tbom`) scans a tracked Git repository for AI SDK, MCP
server, and eval-workflow usage, fuses that inferred evidence with
human-authored manual declarations (`trust/manual.yml`), and compiles a cited,
hash-stable system graph (`trust/card.json`) plus `card.md`,
`questionnaire.yml`, and SARIF findings.

This package ships the same engine as the .NET tool as a self-contained binary.
You do not need the .NET SDK or Docker.

## Install and run

```
npx trustbom scan
npm install --global trustbom
trustbom --version
tbom gate
```

The platform binary comes from one optional dependency per platform
(`win-x64`, `linux-x64`, `linux-arm64`, `osx-arm64`, `osx-x64`); npm installs
only the one that matches your machine. The packages contain no install
scripts and make no network requests after installation, so
`npm install --ignore-scripts` works unchanged.

## Prerequisites

- Node.js 18 or later (only to run the launcher).
- Git.
- Linux: the ICU runtime library (`libicu`, for example `libicu74` on Ubuntu
  24.04) and a glibc-based distribution. Alpine and other musl-based
  distributions are not supported.
- Do not install with `--omit=optional` (`--no-optional`): the binary lives in
  an optional dependency.

## Exit codes

The launcher forwards the exit code of `trustbom` unchanged. It has three codes
of its own, written to standard error with an explanation:

| Code | Meaning |
|---|---|
| `70` | Unsupported platform or architecture |
| `71` | The platform package is not installed (for example `--omit=optional`) |
| `72` | The binary could not be started (for example it is not executable) |

## License

Run `trustbom license` to read the license terms for the installed version, or
see https://resolveinterim.com/aitrustbom/license.html. Documentation:
https://resolveinterim.com/aitrustbom/.
